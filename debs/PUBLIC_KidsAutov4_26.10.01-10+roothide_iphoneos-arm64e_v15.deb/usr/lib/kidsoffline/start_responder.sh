#!/bin/sh
# Self-healing launcher for the offline API responder (run by launchd, as root).
# Running under launchd means apt is NOT blocked by the dpkg lock (unlike postinst),
# so on a fresh machine python3 gets installed here on first start.
if [ -d /var/jb/usr/lib/kidsoffline ]; then
  R=/var/jb
else
  R=
fi
if [ -n "${JB_ROOT:-}" ]; then
  R=${JB_ROOT%/}
fi
if [ -z "$R" ] || [ ! -x "$R/usr/bin/python3" ]; then
  for p in /var/containers/Bundle/Application/.jbroot-*; do
    [ -x "$p/usr/bin/python3" ] && R=$p && break
  done
fi
S="$R/usr/bin/sleep"
[ -x "$S" ] || S=sleep
if [ ! -x "$R/usr/bin/python3" ]; then
  export HOME="${R}/root"
  i=0
  while [ "$i" -lt 8 ]; do
    "$R/usr/bin/apt-get" -y install python3 >/dev/null 2>&1
    if [ ! -x "$R/usr/bin/python3" ]; then
      "$R/usr/bin/apt-get" update >/dev/null 2>&1
      "$R/usr/bin/apt-get" -y install python3 >/dev/null 2>&1
    fi
    [ -x "$R/usr/bin/python3" ] && break
    i=$((i+1))
    "$S" 5
  done
fi
if [ -x "$R/usr/bin/python3" ]; then
  exec "$R/usr/bin/python3" "$R/usr/lib/kidsoffline/responder.py"
fi
exit 1
