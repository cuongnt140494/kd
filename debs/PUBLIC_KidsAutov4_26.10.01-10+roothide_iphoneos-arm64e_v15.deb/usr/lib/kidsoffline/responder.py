#!/usr/bin/env python3
# Offline API responder for Kids Changer crack.
# Runs on the jailbroken phone as root, listens on :80. The daemon's remote
# URLs (v4.kidsautoios.com) are byte-patched to 127.0.0.1, so license /
# login / changedevice calls hit this responder instead of the dead backend.
#
# Per-endpoint behavior:
#   /license      -> mirrors the daemon's local behavior: returns the cached
#                   LicenseKey blob as {"status":"true","message":<key>}
#   /login        -> success JSON (union of shapes the daemon/app may parse)
#   /changedevice -> success JSON
#   /proofdevice  -> {"status":"true","message":"done"}
#   /api/validateinfo -> local DeviceData.json (models and OS versions)
#   /ip...        -> neutral success (cookie sync degrades gracefully)
# Anything custom in /var/jb/kids.MobileTemp/responses.json overrides the
# defaults: {"<path-prefix>": {json body}, ...}
import json, os, socket, time

PORT = int(os.environ.get("RESPONDER_PORT", "80"))
JBROOT = os.environ.get("JB_ROOT", "/var/jb").rstrip("/")
RES = os.path.join(JBROOT, "kids.MobileTemp", "responses.json")
KEY = os.path.join(JBROOT, "kids.MobileTemp", "LicenseKey")
LOG = os.path.join(JBROOT, "kids.MobileTemp", "responder.log")

SUCCESS = {
    "result": True,
    "status": "true",
    "message": "done",
    "err": "",
    "ok": True,
    "info": {},
}

def log(msg):
    try:
        with open(LOG, "a") as f:
            f.write(time.strftime("%m-%d %H:%M:%S ") + msg + "\n")
    except Exception:
        pass

def load_responses():
    try:
        with open(RES) as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}

def license_body():
    try:
        with open(KEY, "rb") as f:
            key = f.read().strip().decode("latin1")
        return json.dumps({"status": "true", "message": key}).encode()
    except Exception:
        return json.dumps(SUCCESS).encode()

def body_for(path):
    custom = load_responses()
    for prefix in sorted(custom, key=len, reverse=True):
        if path.startswith(prefix):
            b = custom[prefix]
            if isinstance(b, (dict, list)):
                return json.dumps(b).encode()
            if isinstance(b, str):
                return b.encode()
            return b
    p = path.split("?", 1)[0]
    if p == "/license":
        return license_body()
    if p == "/proofdevice":
        return b'{"status":"true","message":"done"}'
    if p == "/api/validateinfo":
        with open(os.path.join(JBROOT, "usr/lib/kidsoffline/DeviceData.json"), "rb") as f:
            body = f.read()
        parsed = json.loads(body)
        if not all(k in parsed for k in ("result", "err", "info")) or not all(k in parsed["info"] for k in ("models", "os_versions")):
            raise ValueError("DeviceData.json has invalid validateinfo schema")
        return body
    if p == "/changedevice":
        return json.dumps(SUCCESS).encode()
    if p.startswith("/ip"):
        return b'{"result":true,"err":"","info":{}}'
    log("UNKNOWN route " + p[:160])
    return json.dumps(SUCCESS).encode()

def handle(conn):
    try:
        req = b""
        while b"\r\n\r\n" not in req:
            c = conn.recv(65536)
            if not c:
                break
            req += c
        line = req.split(b"\n", 1)[0].decode("latin1")
        parts = line.split(" ")
        method = parts[0] if parts else "?"
        path = parts[1] if len(parts) > 1 else "/"
        log("REQ %s %s" % (method, path[:160]))
        body = body_for(path)
        out = ("HTTP/1.1 200 OK\r\n"
               "Content-Type: application/json\r\n"
               "Content-Length: %d\r\n"
               "Connection: close\r\n"
               "\r\n" % len(body)).encode() + body
        conn.sendall(out)
    except Exception as e:
        log("ERR %r" % e)
    finally:
        try:
            conn.close()
        except Exception:
            pass

def main():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    while True:
        try:
            s.bind(("0.0.0.0", PORT))
            break
        except OSError as e:
            log("bind :%d failed (%r), retry in 5s" % (PORT, e))
            time.sleep(5)
    s.listen(32)
    log("responder up on :%d" % PORT)
    # TLS on 443 for daemons that still build https:// URLs (needs CA trusted)
    crt = os.path.join(JBROOT, "usr/lib/kidsoffline/server.crt")
    key = os.path.join(JBROOT, "usr/lib/kidsoffline/server.key")
    if os.path.exists(crt) and os.path.exists(key):
        def tls_loop():
            import ssl
            ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
            ctx.load_cert_chain(crt, key)
            t = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            t.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            t.bind(("0.0.0.0", 443))
            t.listen(32)
            log("responder TLS up on :443")
            while True:
                c, _ = t.accept()
                try:
                    handle(ctx.wrap_socket(c, server_side=True))
                except Exception as e:
                    log("TLS ERR %r" % e)
        import threading
        threading.Thread(target=tls_loop, daemon=True).start()
    while True:
        c, _ = s.accept()
        handle(c)

if __name__ == "__main__":
    main()
