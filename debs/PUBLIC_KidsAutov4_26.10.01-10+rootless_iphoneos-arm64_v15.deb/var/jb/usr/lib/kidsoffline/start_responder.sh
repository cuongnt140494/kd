#!/bin/sh
# Self-healing launcher for the offline API responder (run by launchd, as root).
# Running under launchd means apt is NOT blocked by the dpkg lock (unlike postinst),
# so on a fresh machine python3 gets installed here on first start.
#
# Root prefix detection:
#   rootless (Dopamine/Sileo) : /var/jb
#   roothide                  : .jbroot-XXXX symlinks to /, so paths are native ("")
#   rootfull                  : ""
pick_root() {
  if [ -x /usr/bin/python3 ] && [ ! -e /var/jb/usr/lib/kidsoffline/responder.py ]; then
    echo ""; return
  fi
  if [ -x /var/jb/usr/bin/python3 ]; then
    echo "/var/jb"; return
  fi
  if [ -x /usr/bin/python3 ]; then
    echo ""; return
  fi
  for p in /var/containers/Bundle/Application/.jbroot-*; do
    if [ -x "$p/usr/bin/python3" ]; then echo "$p"; return; fi
  done
  echo ""
}
R=$(pick_root)
if [ -n "${JB_ROOT:-}" ] && [ -x "${JB_ROOT%/}/usr/bin/python3" ]; then
  R=${JB_ROOT%/}
fi
S="$R/usr/bin/sleep"
[ -x "$S" ] || S=sleep
if [ ! -x "$R/usr/bin/python3" ]; then
  export HOME="${R}/root"
  i=0
  while [ "$i" -lt 8 ]; do
    "$R/usr/bin/apt-get" -y --allow-unauthenticated install python3 >/dev/null 2>&1
    if [ ! -x "$R/usr/bin/python3" ]; then
      "$R/usr/bin/apt-get" update >/dev/null 2>&1
      "$R/usr/bin/apt-get" -y --allow-unauthenticated install python3 >/dev/null 2>&1
    fi
    [ -x "$R/usr/bin/python3" ] && break
    i=$((i+1))
    "$S" 5
  done
fi
if [ -x "$R/usr/bin/python3" ]; then
  JB_ROOT="$R" exec "$R/usr/bin/python3" "$R/usr/lib/kidsoffline/responder.py"
fi
exit 1
